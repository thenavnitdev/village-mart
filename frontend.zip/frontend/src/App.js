// Bridge file so `index.js` can import './App' even though the real App is in TypeScript
import App from './App.tsx';
export default App;
