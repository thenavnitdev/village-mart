// AppRoutes for react-router-dom
export default function AppRoutes() {
  return null;
}
