// ProtectedRoute for authenticated routes
export default function ProtectedRoute() {
  return null;
}
