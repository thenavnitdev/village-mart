// Product details page
export default function ProductDetails() {
  return null;
}
