// Product list page
export default function ProductList() {
  return null;
}
