// Root store setup (placeholder)
export {};
